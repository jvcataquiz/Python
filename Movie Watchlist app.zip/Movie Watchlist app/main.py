import database
import datetime

menu = """\n\n Please select one of the following options:
1. Add new movie
2. Upcoming Movies
3. All movies
4. Watch a Movie
5. Watched movies
6. Add user
7. Search a movie.
8. Exit

Your selection: """
welcome = "Welcome to the watchlist app!"
loginmenu = """Choice:
"""
def addingMovies():
    title = input("Movie title: ")
    release_date = input("Release date (DD-MM-YYYY): ")
    parsed_date = datetime.datetime.strptime(release_date, "%d-%m-%Y")
    timestamp = parsed_date.timestamp()
    database.add_movie(title, timestamp)
    print("Added Successfully!!!")
def prompt_add_user():
    username = input("Input Username: ")
    database.add_user(username)
    print("Created Successfully!!!" )
def upcomingmovie(username, movies):
    print(f"-- {username} movies --")
    for movie in movies:
        movie_date = datetime.datetime.fromtimestamp(movie[3])
        human_date = movie_date.strftime("%b %d %Y")
        print(f" Id: {movie[0]} \n Title: {movie[1]} \n Date: {human_date}\n\n")
    print("---- \n")
def all_list(heading, movies):
    print(f"-- {heading} movies -- \n")
    for movie in movies:
        movie_date = datetime.datetime.fromtimestamp(movie[3])
        human_date = movie_date.strftime("%b %d %Y")
        print(f" Id: {movie[0]} \n Title: {movie[1]}  \n Date: {human_date}\n\n")
    print("---- \n")

def watched_list(username, movies):
    print(f"\nWelcome: {username}\n")
    for movie in movies:
        movie_date = datetime.datetime.fromtimestamp(movie[3])
        human_date = movie_date.strftime("%b %d %Y")
        print(f"Title: {movie[1]}  \nRating: {movie[4]}/10 \nDate: {human_date}\n\n")
    print("---- \n")
    
def prompt_search_movies():
    search_term = input("Enter partial movie title: ")
    movies = database.search_movies(search_term)  
    rowcount = len(movies)
    if movies:
         print(f"{rowcount} Found !!!")
         for movie in movies:
             print(f"Title: {movie[1]}")
    else:
         print(f"{search_term} Not Found!!!")
       

print(welcome)
database.create_tables()
userInput = input(menu)
while (userInput) != "8":
    if userInput == "1":
        addingMovies()
    elif userInput == "2":
        movies = database.get_movies(True)
        upcomingmovie('Upcoming', movies)
    elif userInput == "3":
        movies = database.get_movies()
        all_list('All', movies)
    elif userInput == "4":
         username = input("Username: ")
         check = database.check_user(username)
         if len(check) > 0:
            movie_id = input("Movie ID: ")
            rate = input("Rating 0/10: ")
            movies = database.watch_movie(username, movie_id,rate)
            print("Thank you for Watching!!!")
         else:
            print("username not registered \nPlease Choose Number 6! \n")
    elif userInput == "5":
         username = input("Username: ")
         movies = database.get_watched_movies(username)
         if movies:
          watched_list(username, movies)
         else:
          print("username not registered or no movie watch \n Please Choose Number 6! \n")
         
    elif userInput == "6":
        prompt_add_user()
    elif userInput == "7":
        movies = prompt_search_movies()

    else:
        print("Invalid input, please try again!")

    userInput = input(menu)